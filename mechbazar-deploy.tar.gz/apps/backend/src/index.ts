import { env } from './config/env';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import compression from 'compression';
import rateLimit from 'express-rate-limit';
import { connectRedis, disconnectRedis } from './config/redis';
import { connectDatabase, disconnectDatabase } from './config/prisma';
import { notFoundHandler, errorHandler } from './middlewares/errorHandler';
import healthRoutes from './routes/health.routes';
import authRoutes from './routes/auth.routes';
import productRoutes from './routes/product.routes';
import orderRoutes from './routes/order.routes';
import vehicleRoutes from './routes/vehicle.routes';
import categoryRoutes from './routes/category.routes';
import warehouseRoutes from './routes/warehouse.routes';
import adminRoutes from './routes/admin.routes';
import inventoryRoutes from './routes/inventory.routes';
import supplierRoutes from './routes/supplier.routes';
import poRoutes from './routes/po.routes';
import customerRoutes from './routes/customer.routes';
import vendorRoutes from './routes/vendor.routes';
import riderRoutes from './routes/rider.routes';
import serviceRoutes from './routes/service.routes';
import technicianRoutes from './routes/technician.routes';
import bannerRoutes from './routes/banner.routes';
import homeRoutes from './routes/home.routes';
import offerRoutes from './routes/offer.routes';
import couponRoutes from './routes/coupon.routes';
import uploadRoutes from './routes/upload.routes';
import newsletterRoutes from './routes/newsletter.routes';
import geocodeRoutes from './routes/geocode.routes';
import jobRoutes from './routes/job.routes';
import { initRealtime, shutdownRealtime } from './realtime/gateway';
import { startSweepers, stopSweepers } from './jobs/sweeper';
// Imported for its side effect: registers the socket location-batch handler
// with the gateway. Without this import the mechanic apps can still POST
// location over HTTP, but the realtime path is silently absent.
import './services/tracking.service';
import swaggerUi from 'swagger-ui-express';
import YAML from 'yamljs';
import path from 'path';
import fs from 'fs';

const app = express();

// Behind the VPS Nginx reverse proxy the client IP arrives via
// X-Forwarded-For; without this, express-rate-limit rejects the header and
// rate-limits all traffic as a single client.
app.set('trust proxy', 1);

// Middlewares
app.use(compression());
app.use(express.json());
// Auth is Bearer-token based (not cookies), so this isn't CSRF-exploitable,
// but a wide-open '*' still lets any origin's JS read authenticated responses
// if it ever gets hold of a token. CORS_ALLOWED_ORIGINS (comma-separated) lets
// ops lock this down per-environment without code changes; unset preserves
// today's permissive default so this can't silently break admin/vendor web
// access on deploy.
const allowedOrigins = (process.env.CORS_ALLOWED_ORIGINS || '')
  .split(',')
  .map((o) => o.trim())
  .filter(Boolean);
app.use(cors(allowedOrigins.length > 0 ? { origin: allowedOrigins } : undefined));
app.use(helmet());
// 'dev' is a verbose, colorized per-request format meant for a local
// terminal; 'combined' (standard Apache-style access log, no ANSI colors) is
// what production log collectors expect.
app.use(morgan(env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// Generous limit on the public API surface; auth routes get a tighter limit
// below since brute-forcing login/OTP is the more sensitive target.
app.use(
  '/api',
  rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 600,
    standardHeaders: true,
    legacyHeaders: false,
  })
);
app.use(
  '/api/auth',
  rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 50,
    standardHeaders: true,
    legacyHeaders: false,
  })
);

// File upload is authenticated but open to every role, including CUSTOMER, and
// each accepted request writes up to 5 MB into a publicly-readable Firebase
// Storage bucket that nothing ever garbage-collects. Under the global /api
// limit alone a single account could push ~3 GB per 15 minutes. This caps it at
// something a real user (a return photo, a KYC document) never reaches.
app.use(
  '/api/upload',
  rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 40,
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: (req, res) => req.headers.authorization || req.ip || 'unknown',
  })
);

// Account deletion is irreversible and authenticated, so the risk isn't
// brute-force but a repeated/duplicated call storm; and the account-mutating
// endpoints below (phone change, profile) are the ones worth spending an
// attacker's stolen-token budget on. Tighter bucket, keyed per user when a
// token is present so one abusive account can't exhaust an entire NAT's quota.
app.use(
  ['/api/customers/me'],
  rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 30,
    standardHeaders: true,
    legacyHeaders: false,
    // Falls back to the default IP key when unauthenticated.
    keyGenerator: (req, res) => req.headers.authorization || req.ip || 'unknown',
  })
);

// Health/readiness -- checked by orchestrators and by this project's own dev
// tooling to distinguish "server not started" from "server started, DB down".
// Mounted both at the root and under /api so external monitors that only know
// the public API prefix (and the mobile apps' connectivity check) can use
// /api/health and /api/status too.
app.use(healthRoutes);
app.use('/api', healthRoutes);

// Swagger Setup -- documents the full internal API surface (including admin
// routes), so it's only mounted outside production. Endpoints still require
// their normal auth regardless; this just avoids publishing a map of them.
if (env.NODE_ENV !== 'production') {
  let swaggerPath = path.join(__dirname, 'swagger.yaml');
  if (!fs.existsSync(swaggerPath)) {
    swaggerPath = path.join(__dirname, '../src/swagger.yaml');
  }
  const swaggerDocument = YAML.load(swaggerPath);
  app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
}

// Routes
app.use('/api/vendors', vendorRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/products', productRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/vehicles', vehicleRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/warehouses', warehouseRoutes);
app.use('/api/inventory', inventoryRoutes);
app.use('/api/suppliers', supplierRoutes);
app.use('/api/purchase-orders', poRoutes);
app.use('/api/customers', customerRoutes);
app.use('/api/riders', riderRoutes);
app.use('/api/services', serviceRoutes);
app.use('/api/technicians', technicianRoutes);
app.use('/api/banners', bannerRoutes);
app.use('/api/home', homeRoutes);
app.use('/api/offers', offerRoutes);
app.use('/api/coupons', couponRoutes);
app.use('/api/upload', uploadRoutes);
app.use('/api/newsletter', newsletterRoutes);
app.use('/api/geocode', geocodeRoutes);
// Emergency breakdown dispatch. Separate from /api/services (which keeps the
// scheduled, slot-based booking flow) because the two have different
// lifecycles, different realtime requirements and different failure modes.
app.use('/api/jobs', jobRoutes);

// Serve static files from uploads directory
// These are public product/category images meant to be displayed by other
// origins (admin/vendor dashboards, the customer web build), so relax CORP
// only for this route rather than for the whole API.
app.use(
  '/uploads',
  (req, res, next) => {
    res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
    next();
  },
  express.static(path.join(process.cwd(), 'uploads'))
);

app.get('/', (req, res) => {
  res.json({ message: 'Welcome to MechBazar API' });
});

app.use(notFoundHandler);
app.use(errorHandler);

startServer();

async function startServer() {
  console.log(`[startup] Starting MechBazar backend (${env.NODE_ENV})...`);

  const server = app
    .listen(env.PORT, '0.0.0.0', () => {
      console.log(`[startup] Server is running on port ${env.PORT} across all interfaces`);
    })
    .on('error', (err: NodeJS.ErrnoException) => {
      if (err.code === 'EADDRINUSE') {
        console.error(
          `\n[FATAL] Port ${env.PORT} is already in use.\n` +
            `Another backend instance (or another app) is already listening on this port.\n` +
            `Stop that process, or set PORT to a different value in apps/backend/.env.\n`
        );
      } else {
        console.error('[FATAL] Failed to start server:', err);
      }
      process.exit(1);
    });

  // Connect to backing services AFTER the HTTP server is already listening, and
  // without blocking on them: a slow or misconfigured DB/Redis must not stop the
  // port from binding. Otherwise Nginx has nothing to proxy to and every request
  // 502s (and, if `npm start` gated on `prisma db push`, the container would
  // crash-loop). connectDatabase() retries forever with backoff, so the API
  // comes up immediately, reports DB health via /api/status, and recovers on its
  // own once connectivity is restored -- which is exactly what prisma.ts's
  // "shouldn't take the whole API down" contract promises.
  connectDatabase().catch((err) => console.error('[db] Fatal connection error:', err));
  connectRedis().catch((err) => console.error('[redis] Fatal connection error:', err));

  // Realtime and the dispatch sweepers attach to the same HTTP server, after
  // it is listening, and on the same non-blocking terms as the DB/Redis
  // connections above: a Socket.IO failure degrades live tracking to the HTTP
  // polling fallback but must never stop the REST API from serving.
  initRealtime(server)
    .then(() => startSweepers())
    .catch((err) => {
      console.error('[realtime] Failed to initialise -- continuing without realtime:', err);
      // Sweepers are independent of the socket layer and are what guarantee no
      // job gets stranded, so they start either way.
      startSweepers();
    });

  let shuttingDown = false;
  const shutdown = async (signal: string) => {
    if (shuttingDown) return;
    shuttingDown = true;
    console.log(`\n[shutdown] Received ${signal}, shutting down gracefully...`);

    // Stop accepting new dispatch work before tearing down connections, so an
    // in-flight sweep can't fire against a closing pool.
    stopSweepers();
    await shutdownRealtime().catch((err) => console.error('[shutdown] realtime close failed:', err));

    server.close(() => console.log('[shutdown] HTTP server closed'));
    await disconnectDatabase();
    await disconnectRedis();

    console.log('[shutdown] Cleanup complete, exiting');
    process.exit(0);
  };

  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('unhandledRejection', (reason) => {
    console.error('[error] Unhandled promise rejection:', reason);
  });
  process.on('uncaughtException', (err) => {
    console.error('[error] Uncaught exception:', err);
  });
}

export default app;
